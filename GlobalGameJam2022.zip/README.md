# GlobalGameJam2022
This is the Development Repository for Global Game Jam 2022

Our Discord Channel: [https://discord.gg/ktbFHBFC](https://discord.gg/ktbFHBFC)

# Builds

Currently there's no build for the game :(

Latest Release: [None]()

Latest Build: [None]()

## Release History

|  Build   |  Dates  |  Notes  |
|  ----  |  ----  |  ----  |
|  None  |  None  |  None  |

# Directories

Please follow the following directory structures to submit or change files

|  Directory   |  Contents  |
|  ----  | ----  |
|  game  |  Codes  |
|  builds  |  Game Builds  |
|  files/audios  |  Audios and BGMs  |
|  files/docs  |  Documents and Word Files  |
|  files/guis  |  Graphical User Interface  |
|  files/images  |  Background and Character Pictures  |
|  files/miscs  |  Misc Files  |

# Branches

Please follow the following branches instructions to submit or change files

|  Branch   |  Notes  |
|  ----  | ----  |
|  main  |  Should be modified only by the owner  |
|  test1  |  Used to test functions and new features  |
|  backup  |  Used to trace back changes  |